"""
Created on Mar 1, 2020
Pytorch Implementation of LightGCN in
Xiangnan He et al. LightGCN: Simplifying and Powering Graph Convolution Network for Recommendation

@author: Jianbai Ye (gusye@mail.ustc.edu.cn)

Define models here
"""
from torch.nn.functional import cosine_similarity

import dataloader
import world
import random
import torch
from dataloader import BasicDataset
from torch import nn
import torch.nn.functional as F
from sklearn.cluster import KMeans
import numpy as np


class BasicModel(nn.Module):    
    def __init__(self):
        super(BasicModel, self).__init__()
    
    def getUsersRating(self, users):
        raise NotImplementedError



class FairLoss(torch.nn.Module):
    def __init__(self, fairness_factor):
        super(FairLoss, self).__init__()
        self.fairness_factor = fairness_factor

    def forward(self, pos_scores, neg_scores):
        diff = pos_scores - neg_scores
        fair_loss = -torch.log(torch.sigmoid(self.fairness_factor * diff))
        return fair_loss.mean()

# 对相似度评分进行归一化处理
def normalize(scores):
    min_val = torch.min(scores)
    max_val = torch.max(scores)
    normalized_scores = (scores - min_val) / (max_val - min_val)
    return normalized_scores

class PairWiseModel(BasicModel):
    def __init__(self):
        super(PairWiseModel, self).__init__()

    def bpr_loss(self, users, pos, neg, idx):
    #def bpr_loss(self, users, pos, neg , fairness_factor):
        """
        Parameters:
            users: users list 
            pos: positive items for corresponding users
            neg: negative items for corresponding users
        Return:
            (log-loss, l2-loss)
        """
        raise NotImplementedError
    
class PureMF(BasicModel):
    def __init__(self, 
                 config:dict, 
                 dataset:BasicDataset):
        super(PureMF, self).__init__()
        self.num_users  = dataset.n_users
        self.num_items  = dataset.m_items
        self.latent_dim = config['latent_dim_rec']
        self.f = nn.Sigmoid()
        self.__init_weight()
        
    def __init_weight(self):
        self.embedding_user = torch.nn.Embedding(
            num_embeddings=self.num_users, embedding_dim=self.latent_dim)
        self.embedding_item = torch.nn.Embedding(
            num_embeddings=self.num_items, embedding_dim=self.latent_dim)
        print("using Normal distribution N(0,1) initialization for PureMF")
        
    def getUsersRating(self, users):
        users = users.long()
        users_emb = self.embedding_user(users)
        items_emb = self.embedding_item.weight
        scores = torch.matmul(users_emb, items_emb.t())
        return self.f(scores)
    
    # def bpr_loss(self, users, pos, neg):
    #     users_emb = self.embedding_user(users.long())
    #     pos_emb   = self.embedding_item(pos.long())
    #     neg_emb   = self.embedding_item(neg.long())
    #     pos_scores= torch.sum(users_emb*pos_emb, dim=1)
    #     neg_scores= torch.sum(users_emb*neg_emb, dim=1)
    #     loss = torch.mean(nn.functional.softplus(neg_scores - pos_scores))
    #     reg_loss = (1/2)*(users_emb.norm(2).pow(2) +
    #                       pos_emb.norm(2).pow(2) +
    #                       neg_emb.norm(2).pow(2))/float(len(users))
    #     return loss, reg_loss
        
    def forward(self, users, items):
        users = users.long()
        items = items.long()
        users_emb = self.embedding_user(users)
        items_emb = self.embedding_item(items)
        scores = torch.sum(users_emb*items_emb, dim=1)
        return self.f(scores)


class LightGCN(BasicModel):
    def __init__(self, 
                 config:dict, 
                 dataset:BasicDataset):
        super(LightGCN, self).__init__()
        self.config = config
        # self.dataset : dataloader.BasicDataset = dataset
        self.dataset = dataset #不指定dataset的类型
        self.__init_weight()

    def __init_weight(self):
        self.num_users  = self.dataset.n_users
        self.num_items  = self.dataset.m_items
        self.latent_dim = self.config['latent_dim_rec']
        self.n_layers = self.config['lightGCN_n_layers']
        self.keep_prob = self.config['keep_prob']
        self.A_split = self.config['A_split']
        self.alpha1 = self.config['alpha1']
        self.alpha2 = self.config['alpha2']
        self.num_cluster = self.config['num_cluster']
        self.masked_adj = None
        self.pruning_random = False
        #self.temperature = 1.0
        self.alpha = 0.2
        self.beta = 0.3
        self.top_H = 4
        self.self_loop = 0
        self.flag = 0
        self.embedding_user = torch.nn.Embedding(
            num_embeddings=self.num_users, embedding_dim=self.latent_dim)
        self.embedding_item = torch.nn.Embedding(
            num_embeddings=self.num_items, embedding_dim=self.latent_dim)
        if self.config['pretrain'] == 0:
#             nn.init.xavier_uniform_(self.embedding_user.weight, gain=1)
#             nn.init.xavier_uniform_(self.embedding_item.weight, gain=1)
#             print('use xavier initilizer')
# random normal init seems to be a better choice when lightGCN actually don't use any non-linear activation function
            nn.init.normal_(self.embedding_user.weight, std=0.1)
            nn.init.normal_(self.embedding_item.weight, std=0.1)
            world.cprint('use NORMAL distribution initilizer')
        else:
            self.embedding_user.weight.data.copy_(torch.from_numpy(self.config['user_emb']))
            self.embedding_item.weight.data.copy_(torch.from_numpy(self.config['item_emb']))
            print('use pretarined data')
        self.f = nn.Sigmoid()
        # 加载邻接矩阵
        self.Graph = self.dataset.getSparseGraph()
        self.adj = self.dataset.get_adj()
        print(f"lgn is already to go(dropout:{self.config['dropout']})")

        # print("save_txt")

    def __dropout_x(self, x, keep_prob):
        size = x.size()
        index = x.indices().t()
        values = x.values()
        random_index = torch.rand(len(values)) + keep_prob
        random_index = random_index.int().bool()
        index = index[random_index]
        values = values[random_index]/keep_prob
        g = torch.sparse.FloatTensor(index.t(), values, size)
        return g
    
    def __dropout(self, keep_prob):
        if self.A_split:
            graph = []
            for g in self.Graph:
                graph.append(self.__dropout_x(g, keep_prob))
        else:
            graph = self.__dropout_x(self.Graph, keep_prob)
        return graph

    #MDGCF
    # def cosine_similarity(self, x, y):
    #     """
    #         get the cosine similarity between to matrix
    #         consin(x, y) = xy / (sqrt(x^2) * sqrt(y^2))
    #     """
    #     x = x - torch.mean(x)
    #     y = y - torch.mean(y)
    #     xy = torch.matmul(x, y.transpose(0, 1))
    #     x_norm = torch.sqrt(torch.mul(x, x).sum(1))
    #     y_norm = torch.sqrt(torch.mul(y, y).sum(1))
    #     x_norm = 1.0 / (x_norm.unsqueeze(1) + 1e-8)
    #     y_norm = 1.0 / (y_norm.unsqueeze(0) + 1e-8)
    #     # xy = torch.mul(torch.mul(xy, x_norm), y_norm)
    #     l = 5
    #     num_b = x.shape[0] // l
    #     if num_b * l < x.shape[0]:
    #         l = l + 1
    #     for i in range(l):
    #         begin = i * num_b
    #         end = (i + 1) * num_b
    #         end = xy.shape[0] if end > xy.shape[0] else end
    #         xy[begin:end] = torch.mul(torch.mul(xy[begin:end], x_norm[begin:end]), y_norm)
    #     return xy
    #
    # def tile(self, a, reps):
    #     expanded_a = a.unsqueeze(1)
    #     tiled_a = expanded_a.repeat(1, *reps).view(-1)
    #     return tiled_a
    #
    # def top_sim(self, sim_adj, toph, num_node):
    #     sim_node = torch.topk(sim_adj, k=toph + self.self_loop, dim=1)
    #     sim_node_value = sim_node.values[:, self.self_loop:].reshape((-1)) / toph
    #     sim_node_col = sim_node.indices[:, self.self_loop:].reshape((-1))
    #     sim_node_row = torch.tensor(range(num_node)).long().reshape((-1, 1))
    #     sim_node_row = self.tile(sim_node_row, [1, toph]).reshape((-1))
    #     sim_node_indices = torch.stack([sim_node_row.to(world.device), sim_node_col.to(world.device)])
    #     sim_adj = torch.sparse.FloatTensor(sim_node_indices, sim_node_value, torch.Size(sim_adj.shape))
    #     return sim_adj
    # def get_consin_adj(self, users_emb, items_emb):
    #     with torch.no_grad():
    #         user_sim = self.cosine_similarity(users_emb, users_emb)
    #         self.user_sim_adj = self.top_sim(user_sim, self.top_H, self.num_users)
    #         del user_sim
    #         item_sim = self.cosine_similarity(items_emb, items_emb)
    #         self.item_sim_adj = self.top_sim(item_sim, self.top_H, self.num_items)
    #         del item_sim
    # def get_interaction_adj(self, emb_u, emb_i):
    #     with torch.no_grad():
    #         sim = torch.sigmoid(torch.matmul(emb_u, emb_i.transpose(0, 1)))
    #         adj = self.adj.to_dense()
    #         if self.dataset == 'Gowalla':
    #             l = 5
    #             num_b = sim.shape[0] // l
    #             if num_b * l < sim.shape[0]:
    #                 l = l + 1
    #             for i in range(l):
    #                 begin = i * num_b
    #                 end = (i + 1) * num_b
    #                 end = sim.shape[0] if end > sim.shape[0] else end
    #                 adj[begin:end] = (1 - self.beta) * torch.mul(adj[begin:end], sim[begin:end]) + self.beta * adj[
    #                                                                                                            begin:end]
    #         else:
    #             adj = (1 - self.beta) * adj * sim + self.beta * adj
    #     return adj
    #
    # def get_flag(self):
    #     return self.flag % 10

    # def computer(self):
    #     emb_u = self.embedding_user.weight
    #     emb_i = self.embedding_item.weight
    #     adj = self.get_interaction_adj(emb_u, emb_i)
    #     users_embs = [emb_u]
    #     items_embs = [emb_i]
    #     for layer in range(self.n_layers):
    #         emb_u = torch.mm(adj, items_embs[-1])
    #         emb_i = torch.mm(adj.transpose(0, 1), users_embs[-1])
    #         users_embs.append(emb_u)
    #         items_embs.append(emb_i)
    #     del adj
    #
    #     if self.get_flag() == 0:
    #         self.get_consin_adj(emb_u, emb_i)
    #     sim_emb_u = torch.sparse.mm(self.user_sim_adj, self.embedding_user.weight)
    #     sim_emb_i = torch.sparse.mm(self.item_sim_adj, self.embedding_item.weight)
    #
    #     users_embs = torch.stack(users_embs, dim=1)
    #     items_embs = torch.stack(items_embs, dim=1)
    #     users_embs = torch.mean(users_embs, dim=1)
    #     items_embs = torch.mean(items_embs, dim=1)
    #
    #     users = users_embs + self.alpha * sim_emb_u
    #     items = items_embs + self.alpha * sim_emb_i
    #     del sim_emb_i, sim_emb_u
    #     return users, items

    #LightGCN
    def computer(self):
        """
        propagate methods for lightGCN
        """
        users_emb = self.embedding_user.weight
        items_emb = self.embedding_item.weight
        all_emb = torch.cat([users_emb, items_emb])
        #   torch.split(all_emb , [self.num_users, self.num_items])
        embs = [all_emb]
        if self.config['dropout']:
            if self.training:
                print("droping")
                g_droped = self.__dropout(self.keep_prob)
            else:
                g_droped = self.Graph
        else:
            g_droped = self.Graph
        for _ in range(self.n_layers):
            all_emb = torch.sparse.mm(g_droped, all_emb)
            embs.append(all_emb)
        embs = torch.stack(embs, dim=1)
        light_out = torch.mean(embs, dim=1)
        users, items = torch.split(light_out, [self.num_users, self.num_items])
        return users, items

    #DAP
    def computer_DAP(self):
        users_emb = self.embedding_user.weight
        items_emb = self.embedding_item.weight
        all_emb = torch.cat([users_emb, items_emb])
        u_degree = torch.tensor(self.dataset.users_D)
        i_degree = torch.tensor(self.dataset.items_D)
        degree = torch.cat([u_degree, i_degree], dim=0)
        all_embs_anchor_higher = torch.zeros([self.num_users + self.num_items, self.latent_dim]).to(world.device)
        all_embs_anchor_lower = torch.zeros([self.num_users + self.num_items, self.latent_dim]).to(world.device)
        embs = [all_emb]
        g_droped = self.Graph

        weight1 = self.config['alpha1']
        weight2 = self.config['alpha2']
        num_cluster = self.config['num_cluster']
        print(f'weight1={weight1},weight2={weight2}, num_cluster:{num_cluster}')
        for layer in range(self.n_layers):
            all_emb_i = torch.sparse.mm(g_droped, all_emb)
            kmeans = KMeans(n_clusters=num_cluster, random_state=9)
            #world.cprint(f'GCN debiasing at {layer + 1}-layer')
            all_emb_cluster = kmeans.fit_predict(all_emb_i.to('cpu'))
            for k_cluster in range(num_cluster):
                index = np.where(all_emb_cluster == k_cluster)
                embs_cluster = all_emb_i[index[0]]
                degree_cluster = degree[index[0]].unsqueeze(1)
                for i in range(len(index[0])):
                    if degree[index[0][i]] > degree_cluster.min() and degree[index[0][i]] < degree_cluster.max():
                        degree_higher_index = torch.where(degree_cluster > degree[index[0][i]])
                        degree_lower_index = torch.where(degree_cluster < degree[index[0][i]])
                        embs_higher_mean = embs_cluster[degree_higher_index[0]].mean(0)
                        embs_lower_mean = embs_cluster[degree_lower_index[0]].mean(0)
                        all_embs_anchor_higher[index[0][i]] = embs_higher_mean
                        all_embs_anchor_lower[index[0][i]] = embs_lower_mean
                    elif degree[index[0][i]] == degree_cluster.min():
                        degree_higher_index = torch.where(degree_cluster > degree[index[0][i]])
                        embs_higher_mean = embs_cluster[degree_higher_index[0]].mean(0)
                        all_embs_anchor_higher[index[0][i]] = embs_higher_mean
                    elif degree[index[0][i]] == degree_cluster.max():
                        degree_lower_index = torch.where(degree_cluster < degree[index[0][i]])
                        embs_lower_mean = embs_cluster[degree_lower_index[0]].mean(0)
                        all_embs_anchor_lower[index[0][i]] = embs_lower_mean
            all_embs_anchor_higher = nn.functional.normalize(all_embs_anchor_higher)
            all_embs_anchor_lower = nn.functional.normalize(all_embs_anchor_lower)
            alpha_sim_higher = cosine_similarity(all_emb, all_embs_anchor_higher.to(world.device))
            alpha_sim_lower = cosine_similarity(all_emb, all_embs_anchor_lower.to(world.device))
            all_emb = all_emb_i - weight1 * alpha_sim_higher.unsqueeze(1).to(world.device) * all_embs_anchor_higher.to(
                world.device) \
                      - weight2 * alpha_sim_lower.unsqueeze(1).to(world.device) * all_embs_anchor_lower.to(world.device)
            # all_emb = all_emb_i - weight1 * all_embs_anchor_higher.to(world.device) - weight2 * all_embs_anchor_lower.to(world.device)
            # all_emb = all_emb_i - weight * alpha_sim_lower.unsqueeze(1).to(world.device) * all_embs_anchor_lower.to(world.device)
            embs.append(all_emb)
        embs = torch.stack(embs, dim=1)
        light_out = torch.mean(embs, dim=1)
        users, items = torch.split(light_out, [self.num_users, self.num_items])
        return users, items

    def getUsersRating(self, users):
        all_users, all_items = self.computer()
        users_emb = all_users[users.long()]
        items_emb = all_items
        rating = self.f(torch.matmul(users_emb, items_emb.t()))
        return rating
    def getUsersRating_test(self, users):
        all_users, all_items = self.computer_DAP()
        users_emb = all_users[users.long()]
        items_emb = all_items
        rating = self.f(torch.matmul(users_emb, items_emb.t()))
        return rating
    
    def getEmbedding(self, users, pos_items, neg_items):
        all_users, all_items = self.computer()
        users_emb = all_users[users]
        pos_emb = all_items[pos_items]
        neg_emb = all_items[neg_items]
        users_emb_ego = self.embedding_user(users)
        pos_emb_ego = self.embedding_item(pos_items)
        neg_emb_ego = self.embedding_item(neg_items)
        return users_emb, pos_emb, neg_emb, users_emb_ego, pos_emb_ego, neg_emb_ego

    def bpr_loss(self, users, pos, neg, fairness_factor):
        users_emb = self.embedding_user(users.long())
        pos_emb = self.embedding_item(pos.long())
        neg_emb = self.embedding_item(neg.long())
        pos_scores = torch.sum(users_emb * pos_emb, dim=1)
        neg_scores = torch.sum(users_emb * neg_emb, dim=1)
        #loss = torch.mean(nn.functional.softplus(neg_scores - pos_scores))
        reg_loss = (1 / 2) * (users_emb.norm(2).pow(2) +
                              pos_emb.norm(2).pow(2) +
                              neg_emb.norm(2).pow(2)) / float(len(users))
        # 计算公平性损失
        fair_criterion = FairLoss(fairness_factor)
        fair_loss = fair_criterion(pos_scores, neg_scores)
        # 计算BPR损失
        bpr_losses = -torch.log(torch.sigmoid(pos_scores - neg_scores))
        # 取平均损失
        bpr_loss = bpr_losses.mean()
        # 将公平性损失与BPR损失相结合
        loss = bpr_loss + fair_loss
        return loss, reg_loss


    # def bpr_loss(self, users, pos, neg):
    #     users_emb = self.embedding_user(users.long())
    #     pos_emb   = self.embedding_item(pos.long())
    #     neg_emb   = self.embedding_item(neg.long())
    #     pos_scores= torch.sum(users_emb*pos_emb, dim=1)
    #     neg_scores= torch.sum(users_emb*neg_emb, dim=1)
    #     # loss = torch.mean(nn.functional.softplus(neg_scores - pos_scores))
    #     loss = torch.mean(-torch.log(torch.sigmoid(pos_scores - neg_scores)))
    #     reg_loss = (1/2)*(users_emb.norm(2).pow(2) +
    #                       pos_emb.norm(2).pow(2) +
    #                       neg_emb.norm(2).pow(2))/float(len(users))
    #     return loss, reg_loss



    def forward(self, users, items):
        # compute embedding
        all_users, all_items = self.computer()
        # print('forward')
        #all_users, all_items = self.computer()
        users_emb = all_users[users]
        items_emb = all_items[items]
        # inner_pro = torch.mul(users_emb, items_emb)
        # gamma     = torch.sum(inner_pro, dim=1)
        inner_prod = torch.sum(torch.mul(users_emb, items_emb), dim=1)
        gamma = normalize(inner_prod)
        return gamma
